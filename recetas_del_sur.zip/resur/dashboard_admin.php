<?php
session_start();
include 'includes/Database.php'; // Incluye tu archivo de conexión a la base de datos

// Verificar si el usuario es un administrador logueado
if (!isset($_SESSION['user_id']) || $_SESSION['user_tipo'] !== 'admin') {
    header("Location: login.php"); // Si no está logueado o no es admin, redirige al login
    exit;
}

// Obtener los datos del administrador desde la sesión
$adminId = $_SESSION['user_id'];
$adminNombre = $_SESSION['user_nombre'];
$adminCorreo = $_SESSION['user_email']; // Ahora accede al correo correctamente

// Clases PHP con POO
class RecetaManager {
    public function gestionar() {
        return "Funcionalidad para gestionar recetas activada.";
    }
}

class CategoriaManager {
    public function gestionar() {
        return "Funcionalidad para gestionar categorías activada.";
    }
}

class ReporteManager {
    public function visualizar() {
        return "Funcionalidad para visualizar reportes activada.";
    }
}

// Lógica de cierre de sesión
if (isset($_POST['accion']) && $_POST['accion'] === 'cerrar_sesion') {
    session_destroy(); // Destruye la sesión actual
    header("Location: login.php"); // Redirige al login
    exit;
}

// Verificando acciones enviadas por el usuario
$accion = isset($_POST['accion']) ? $_POST['accion'] : null;
$resultado = "";

if ($accion) {
    switch ($accion) {
        case 'recetas':
            $gestorRecetas = new RecetaManager();
            $resultado = $gestorRecetas->gestionar();
            break;
        case 'categorias':
            $gestorCategorias = new CategoriaManager();
            $resultado = $gestorCategorias->gestionar();
            break;
        case 'reportes':
            $gestorReportes = new ReporteManager();
            $resultado = $gestorReportes->visualizar();
            break;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Administrador</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
        }
        header {
            background: #35424a;
            color: #ffffff;
            padding-top: 30px;
            min-height: 70px;
            border-bottom: #e8491d 3px solid;
        }
        header h1 {
            text-align: center;
            margin: 0;
            font-size: 24px;
        }
        .menu {
            display: flex;
            justify-content: center;
            margin: 20px 0;
        }
        .menu button {
            margin: 0 10px;
            padding: 10px 20px;
            font-size: 16px;
            background-color: #35424a;
            color: white;
            border: none;
            cursor: pointer;
        }
        .menu button:hover {
            background-color: #e8491d;
        }
        .result {
            margin: 20px 0;
            text-align: center;
            font-size: 18px;
            color: #333;
        }
        .logout {
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <header>
    <h1>Bienvenido, <?php echo $adminNombre; ?></h1> <!-- Muestra el nombre del administrador -->
    </header>
    <div class="container">
        <div class="menu">
            <form method="POST">
                <button type="submit" name="accion" value="recetas">Gestionar Recetas</button>
                <button type="submit" name="accion" value="categorias">Gestionar Categorías</button>
                <button type="submit" name="accion" value="reportes">Ver Reportes</button>
            </form>
        </div>
        <?php if ($resultado): ?>
            <div class="result">
                <?php echo $resultado; ?>
            </div>
        <?php endif; ?>
        <div class="logout">
            <form method="POST">
                <button type="submit" name="accion" value="cerrar_sesion">Cerrar Sesión</button>
            </form>
        </div>
    </div>
</body>
</html>
