<?php
session_start();

class Usuario {
    private $nombre;
    private $correo;

    public function __construct($nombre, $correo) {
        $this->nombre = $nombre;
        $this->correo = $correo;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getCorreo() {
        return $this->correo;
    }
}

// Lógica de cierre de sesión
if (isset($_POST['accion']) && $_POST['accion'] === 'cerrar_sesion') {
    session_destroy(); // Destruye la sesión actual
    header("Location: login.php"); // Redirige al login
    exit;
}

// Simulación de datos del usuario logueado
$usuario = new Usuario("Ana López", "usuario@recetas.com");

// Verificando acciones enviadas por el usuario
$accion = isset($_POST['accion']) ? $_POST['accion'] : null;
$resultado = "";

if ($accion) {
    switch ($accion) {
        case 'ver_recetas':
            $viewer = new class {
                public function visualizar() {
                    return "Aquí puedes explorar las recetas disponibles.";
                }
            };
            $resultado = $viewer->visualizar();
            break;
        case 'recetas_guardadas':
            $gestorGuardadas = new class {
                public function gestionar() {
                    return "Aquí puedes ver y gestionar tus recetas guardadas.";
                }
            };
            $resultado = $gestorGuardadas->gestionar();
            break;
        case 'foro':
            $gestorForo = new class {
                public function participar() {
                    return "Bienvenido al foro. ¡Participa y comparte tus ideas!";
                }
            };
            $resultado = $gestorForo->participar();
            break;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Usuario</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
        }
        header {
            background: #35424a;
            color: #ffffff;
            padding: 20px 0;
            text-align: center;
        }
        header h1 {
            margin: 0;
            font-size: 24px;
        }
        .menu {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            margin: 20px 0;
        }
        .menu button {
            margin: 10px;
            padding: 10px 20px;
            font-size: 16px;
            background-color: #35424a;
            color: white;
            border: none;
            cursor: pointer;
        }
        .menu button:hover {
            background-color: #e8491d;
        }
        .result {
            margin: 20px 0;
            text-align: center;
            font-size: 18px;
            color: #333;
        }
        .logout {
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Bienvenido/a, <?php echo $usuario->getNombre(); ?></h1>
    </header>
    <div class="container">
        <div class="menu">
            <form method="POST">
                <button type="submit" name="accion" value="ver_recetas">Ver Recetas</button>
                <button type="submit" name="accion" value="recetas_guardadas">Recetas Guardadas</button>
                <button type="submit" name="accion" value="foro">Foro</button>
            </form>
        </div>
        <?php if ($resultado): ?>
            <div class="result">
                <?php echo $resultado; ?>
            </div>
        <?php endif; ?>
        <div class="logout">
            <form method="POST">
                <button type="submit" name="accion" value="cerrar_sesion">Cerrar Sesión</button>
            </form>
        </div>
    </div>
</body>
</html>
